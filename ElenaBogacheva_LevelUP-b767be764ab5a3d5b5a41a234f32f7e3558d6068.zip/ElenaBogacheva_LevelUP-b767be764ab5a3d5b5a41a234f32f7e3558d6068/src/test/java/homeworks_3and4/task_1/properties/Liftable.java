package homeworks_3and4.task_1.properties;

public interface Liftable {
}
