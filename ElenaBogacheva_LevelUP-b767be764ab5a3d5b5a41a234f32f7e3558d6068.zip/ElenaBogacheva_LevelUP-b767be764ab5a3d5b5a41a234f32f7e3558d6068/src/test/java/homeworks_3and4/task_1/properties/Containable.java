package homeworks_3and4.task_1.properties;

public interface Containable {

    public void capacity();
}
