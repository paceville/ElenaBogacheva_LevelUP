package homeworks_3and4.task_1.modeOfTransport;

public enum PlaneType {
    A220,
    A320,
    A321,
    A330,
    A350,
    A380,
    BOEING_737,
    BOEING_747,
    BOEING_767,
    BOEING_777;
}
