package homeworks_3and4.task_1.modeOfTransport;

public enum AircraftsType {
    PLANE,
    HELICOPTER,
    MULTICOPTER,
    AIRSHIP,
    GAS_BALLON;
}
