package homeworks_3and4.task_1.modeOfTransport;

public enum HelicoptersType {
    AMERICAN_SPORTSCOPTER, //USA
    AGUSTA_WESTLAND, //Italy
    BELL, //USA
    EUROCOPTER; //France
}
