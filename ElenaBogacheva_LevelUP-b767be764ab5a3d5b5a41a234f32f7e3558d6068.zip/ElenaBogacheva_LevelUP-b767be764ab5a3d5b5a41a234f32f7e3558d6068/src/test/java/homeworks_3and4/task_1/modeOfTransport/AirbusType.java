package homeworks_3and4.task_1.modeOfTransport;

public enum AirbusType {
    A220,
    A320,
    A321,
    A330,
    A350,
    A380;
}
