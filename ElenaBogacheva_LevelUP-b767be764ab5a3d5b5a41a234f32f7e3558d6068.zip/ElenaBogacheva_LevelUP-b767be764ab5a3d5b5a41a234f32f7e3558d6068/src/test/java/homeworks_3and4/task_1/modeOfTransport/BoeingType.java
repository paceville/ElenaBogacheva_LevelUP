package homeworks_3and4.task_1.modeOfTransport;

public enum BoeingType {
    BOEING_737,
    BOEING_747,
    BOEING_767,
    BOEING_777;
}
