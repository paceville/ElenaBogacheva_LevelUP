package homeworks_3and4.task_1.airlines;

import java.util.ArrayList;

public interface SettingList {

    public ArrayList<Airlines> airlinesList();

    void add(Airlines airline);
}
