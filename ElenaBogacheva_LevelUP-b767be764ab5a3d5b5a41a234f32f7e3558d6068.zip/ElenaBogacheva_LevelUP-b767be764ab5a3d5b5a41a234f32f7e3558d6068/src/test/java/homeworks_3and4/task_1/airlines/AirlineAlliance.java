package homeworks_3and4.task_1.airlines;

public enum AirlineAlliance {
    STAR_ALLIANCE,
    SKY_TEAM,
    ONEWORLD,
    VALUE_ALLIANCE,
    U_FLY_ALLIANCE,
    VANILA_ALLIANCE;
}
