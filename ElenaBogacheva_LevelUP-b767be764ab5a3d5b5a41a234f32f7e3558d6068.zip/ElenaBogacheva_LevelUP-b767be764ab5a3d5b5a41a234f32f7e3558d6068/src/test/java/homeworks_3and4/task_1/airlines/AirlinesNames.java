package homeworks_3and4.task_1.airlines;

public enum AirlinesNames {
    AMERICAN_AIRLINES,
    LUFTHANSA,
    AIR_MALTA,
    AIR_FRANCE,
    ALITALIA,
    KLM;
}
