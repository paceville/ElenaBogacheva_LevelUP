package homework_2.task_1;

public class Calculator_app {
    public static void main(String[] args) {
        Calculator appCalculator = new Calculator();
        appCalculator.startApplication();
    }
}
